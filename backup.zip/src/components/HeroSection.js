import React from "react";

const HeroSection = () => {
  return (
    <div class="herosection">Hero Section</div>
  );
};

export default HeroSection