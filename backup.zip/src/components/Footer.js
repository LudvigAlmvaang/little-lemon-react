import React from "react";

const Footer = () => {
  return (
    <div class="footer">Footer</div>
  );
};

export default Footer