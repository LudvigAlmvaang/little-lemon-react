import React from "react";

const Highlights = () => {
  return (
    <div class="highlights">Highlights</div>
  );
};

export default Highlights