import React from "react";

const About = () => {
  return (
    <div class="about">About</div>
  );
};

export default About