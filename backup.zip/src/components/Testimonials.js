import React from "react";

const Testimonials = () => {
  return (
    <div class="testimonials">Testimonials</div>
  );
};

export default Testimonials